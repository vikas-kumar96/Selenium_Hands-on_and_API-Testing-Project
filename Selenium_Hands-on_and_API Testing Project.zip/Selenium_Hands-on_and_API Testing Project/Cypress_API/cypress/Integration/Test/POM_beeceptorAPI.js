///<reference types="Cypress"/>
import RestApi from "../../support/PageObject/BeeceptorAPI";
describe('API Testing with Cypress', ()=>{

let burl="https://json-placeholder.mock.beeceptor.com";

const randomEmail = Math.random().toString(2).substring(5);
    
let RAPI = new RestApi();

    it('auth', () =>{
        RAPI.auth("POST",burl,"/api-clients/", {
                "clientName": "vikas",
             "clientEmail": "VikasB"+randomEmail+"@gamil.com"
            })

        });

    });
