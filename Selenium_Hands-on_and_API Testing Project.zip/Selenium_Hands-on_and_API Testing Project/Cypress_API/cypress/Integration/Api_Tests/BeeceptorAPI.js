///<reference types="Cypress"/>
describe('API Testing with Cypress', () => {

    const baseUrl = 'https://json-placeholder.mock.beeceptor.com';

    it('List all available blog posts', () => {
        cy.request('${baseUrl}/posts').then((response) => {
            expect(response.status).to.eq(200);
        });
    });

    it('Retrieve a post by passing an integer ID', () => {
        cy.request('${baseUrl}/posts/1').then((response) => {
            expect(response.status).to.eq(200);
        });
    });

    it('Listing all the blog comments', () => {
        cy.request('${baseUrl}/comments').then((response) => {
            expect(response.status).to.eq(200);
        });
    });

    it('Retrieve a comment by passing a numeric/alphanumeric ID', () => {
        cy.request('${baseUrl}/comments/1').then((response) => {
            expect(response.status).to.eq(200);
        });
    });

    it('Login example with failed attempt', () => {
        cy.request({
            method: 'POST',
            url: '${baseUrl}/login',
            body: { username: 'user123', password: 'failed-password' },
            failOnStatusCode: false
        }).then((response) => {
            expect(response.status).to.eq(401);
        });
    });

    it('Login the user successfully and generate a JWT token', () => {
        cy.request('POST', '${baseUrl}/login', {
            username: 'michael',
            password: 'success-password'
        }).then((response) => {
            expect(response.status).to.eq(200);
            expect(response.body).to.have.property('token');
        });
    });

    it('Default response. Returns metadata about this API', () => {
        cy.request(baseUrl).then((response) => {
            expect(response.status).to.eq(200);
        });
    });

});
